License of skybox used in the demo:

SkyboxSet by Heiko Irrgang is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License. Based on a work at 93i.de.